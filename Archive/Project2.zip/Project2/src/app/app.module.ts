import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FeedComponent } from './feed/feed.component';
import { PostService } from './shared/post.service';
import { HttpClientModule } from '@angular/common/http';

import { LoginComponent } from './login/login.component';

import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ProfileInfoComponent } from './profile-info/profile-info.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ProfileServService } from './shared/profile-serv.service';
import { SideBarComponent } from './side-bar/side-bar.component';
import { ChangePasswordComponent } from './change-password/change-password.component';

@NgModule({
  declarations: [
    AppComponent,
    FeedComponent,
    LoginComponent,
    ProfileInfoComponent,
    NavbarComponent,
    SideBarComponent,
    ChangePasswordComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path: 'profileInfo', component: ProfileInfoComponent },
      {path: 'login', component: LoginComponent },
      {path: 'feed', component: FeedComponent },
      {path: 'User', component: SideBarComponent },
      {path: 'change', component: ChangePasswordComponent }
       ])
  ],
  providers: [PostService, ProfileServService],
  bootstrap: [AppComponent]
})
export class AppModule { }
