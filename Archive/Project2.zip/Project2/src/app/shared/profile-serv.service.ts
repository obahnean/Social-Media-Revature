import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


interface User {
  'userId': string;
  'username': string;
  'fname': string;
  'lname': string;
  'email': string;
}

@Injectable({
  providedIn: 'root'
})

export class ProfileServService {
  private path = 'https://api.myjson.com/bins/y3zyh'; // Path to json goes here.
  constructor(private httCli: HttpClient) { }

  getUser(): Observable<User> {
    return this.httCli.get<User>(this.path);
  }
}
