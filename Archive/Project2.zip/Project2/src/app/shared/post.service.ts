import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Post } from '../models/Post';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  posts = [
    {
      postId: 1,

      author: 'me',

      body: 'this is mah first post',

      image: 'https://a1cf74336522e87f135f-2f21ace9a6cf0052456644b80fa06d4f.ssl.cf2.rackcdn.' +
        'com/images/characters/p-kill-bill-uma-thurman.jpg',

      timestamp: '5AM',

      likes: 15
    }, {
      postId: 2,

      author: 'me',

      body: 'this is the second ever post for socialite',

      image: 'https://a1cf74336522e87f135f-2f21ace9a6cf0052456644b80fa06d4f.ssl.cf2.rackcdn.' +
        'com/images/characters/p-kill-bill-uma-thurman.jpg',

      timestamp: '6AM',

      likes: 20
    }, {
      postId: 3,

      author: 'me',

      body: 'final post. socialite is through',

      image: 'https://a1cf74336522e87f135f-2f21ace9a6cf0052456644b80fa06d4f.ssl.cf2.rackcdn.' +
        'com/images/characters/p-kill-bill-uma-thurman.jpg',

      timestamp: '7AM',

      likes: 47
    }
  ];

  constructor(private httpcli: HttpClient) { }

  getposts() {
    // return this.httpcli.get<Post[]>('https://localhost:8080/Project2/posts.get');
    return this.posts;
  }
}
