import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private url = 'http://10.226.41.133:8080/Project2/login.MasterServlet';

  constructor(private httpCli: HttpClient) { }

  doLogin(uname: string, pword: string): Observable<boolean> {
    const body = JSON.stringify({username: uname, password: pword});
    console.log(body);
    return this.httpCli.post<boolean>(this.url, body);
  }
}
