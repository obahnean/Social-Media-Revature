import { Component, OnInit } from '@angular/core';
import { ProfileServService } from '../shared/profile-serv.service';

@Component({
  selector: 'app-profile-info',
  templateUrl: './profile-info.component.html',
  styleUrls: ['./profile-info.component.css']
})
export class ProfileInfoComponent implements OnInit {
/*   user$: User[];
 */
  constructor(private profileS: ProfileServService) { }
  private username = '';
  private fname = '';
  private lname = '';
  
  ngOnInit() {
  }

  ProfileClick() {
    this.profileS.getUser().subscribe(
      data => {
        const username = 'username';
        const fname = 'fname';
        const lname = 'lname';
        console.log(data[username]);
        this.username = data[username];
        this.fname = data[fname];
        this.lname = data[lname];
      });
  }
  
}
