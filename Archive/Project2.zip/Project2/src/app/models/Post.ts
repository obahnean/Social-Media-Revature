
export interface Post {
    postId;

    author;

    body;

    image;

    timestamp;

    likes;
}
