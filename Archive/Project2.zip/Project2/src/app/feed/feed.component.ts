import { Component, OnInit } from '@angular/core';
import { PostService } from '../shared/post.service';
import { Post } from '../models/Post';

@Component({
  selector: 'app-feed',
  templateUrl: './feed.component.html',
  styleUrls: ['./feed.component.css']
})
export class FeedComponent implements OnInit {
  posts = [
    {
      postId: 1,

      author: 'me',

      body: 'this is mah first post',

      image: 'https://a1cf74336522e87f135f-2f21ace9a6cf0052456644b80fa06d4f.ssl.cf2.rackcdn.' +
        'com/images/characters/p-kill-bill-uma-thurman.jpg',

      timestamp: '5AM',

      likes: 15
    }, {
      postId: 2,

      author: 'me',

      body: 'this is the second ever post for socialite',

      image: 'https://a1cf74336522e87f135f-2f21ace9a6cf0052456644b80fa06d4f.ssl.cf2.rackcdn.' +
        'com/images/characters/p-kill-bill-uma-thurman.jpg',

      timestamp: '6AM',

      likes: 20
    }, {
      postId: 3,

      author: 'me',

      body: 'final post. socialite is through',

      image: 'https://a1cf74336522e87f135f-2f21ace9a6cf0052456644b80fa06d4f.ssl.cf2.rackcdn.' +
        'com/images/characters/p-kill-bill-uma-thurman.jpg',

      timestamp: '7AM',

      likes: 47
    }
  ];

  constructor(private postService: PostService) {
  }

  ngOnInit() {
    this.posts = this.postService.getposts();
  }
  showPosts() {
    /*     this.postService.getposts().subscribe(
          data => {
            this.posts = data;
          }
        ) */
  }
}
