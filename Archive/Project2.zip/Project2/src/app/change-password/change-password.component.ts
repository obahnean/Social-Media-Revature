import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-change-password",
  templateUrl: "./change-password.component.html",
  styleUrls: ["./change-password.component.css"]
})
export class ChangePasswordComponent implements OnInit {
  renew: any;
  username: any;
  password: any;
  newpass: any;
  constructor() {}

  ngOnInit() {}

  handleChange() {
    console.log({
      username: this.username,
      password: this.password,
      newPassword: this.newpass,
      retypeNew: this.renew
    });
  }
}
